n=input('n=');
x=5; o=20; 
m=1; 
R=normrnd(x,o,m,n); 
subplot(3,1,1); 
plot(R); 
title(['n=',num2str(n)]);
Rtao=xcorr(R); 
subplot(3,1,2); 
plot(Rtao);
title('自相关函数Rtao');
Pf=abs(fft(Rtao,2048)); 
subplot(3,1,3); 
plot(Pf);
title('频谱分析');


m=1; 
n=input('n=');
a=0;b=0.5;  
R=unifrnd(a,b,m,n); 
Rtao=xcorr(R); 
subplot(3,1,1); 
plot(R);
title(['n=',num2str(n)]); 
Pf=abs(fft(Rtao,10000)); 
subplot(3,1,2); 
plot(Rtao);
title('自相关函数Rtao'); 
subplot(3,1,3); 
plot(Pf);
title('频谱分析');


n=input('n=');  
m=1; 
p=0.42;
N=1; 
R=binornd(N,p,m,n); 
subplot(3,1,1) 
plot(R); 
title(['n=',num2str(n)]);
Rtao=xcorr(R); 
subplot(3,1,2);
plot(Rtao) 
title('自相关函数Rtao'); 
Pf=abs(fft(Rtao,10000)); 
subplot(3,1,3); 
plot(Pf);
title('频谱分析');