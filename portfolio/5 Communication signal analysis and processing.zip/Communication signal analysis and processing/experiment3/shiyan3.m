Rx=5*ones(1); 
Mx = mean(Rx)
n2=0:999; 
h=(20/21).^n2; %r=1-1/(20+1)=20/21
Rxy=conv(Rx,h); 
h2=(20/21).^(-n2); 
Ry=conv(Rxy,h2); 
My = mean(Ry)
n=-999:999; 
subplot(3,1,1);stem(n,Ry); 
title('Y');
s1=abs(fft(Ry,2048)); 
n=0:2047; 
subplot(3,1,2);plot(n,fftshift(s1)); 
title('频谱图');
x=wgn(1,10000,5'); 
y=x.^2; 
Ry2=xcorr(y,'unbiased'); 
s2=abs(fft(Ry2,32768)); 
n=0:32767; 
subplot(3,1,3);plot(n,fftshift(s2));
title('自相关函数')