clear all;
close all;
N=4096;
x1=random('normal',0,1,1,N);
Sx=abs(fft(x1)).^2/N;
w=-1:2/(N-1):1;
SxdB=10*log10(Sx(1:N));
figure
Rx1=xcorr(x1,'biased');
Sx1=abs(fftshift(fft(Rx1)));
w=-1:2/(2*N-2):1;
Sx1dB=10*log10(Sx1(1:2*N-1));
subplot(1,1,1)
plot(w,Sx1dB)
xlabel('数字角频率rad/s');
ylabel('功率谱密度 dB');
title('功率谱密度自相关函数法')