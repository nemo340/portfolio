clear all;
close all;
N=4096;
x_1=random('normal',0,1,1,N);
Sx=abs(fft(x_1)).^2/N;
w=-1:2/(N-1):1;
SxdB=10*log10(Sx(1:N));
figure
subplot(1,1,1)
plot(w,SxdB)
xlabel('数字角频率 rad/s');
ylabel('信号的功率谱密度 dB')
title('功率谱密度周期图法 ')